# EduPlatform Django config package
